<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="description" content="Welcome To SMIT">
    <meta name="keywords" content="HTML5 Template">
    <meta name="author" content="Smit.com">
    <title>Gallery - SMIT</title>
    <!-- Favicons -->
    <link href="assets/img/favicon" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com" rel="preconnect">
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome/css/all.min.css" rel="stylesheet">

    <!-- Main CSS File -->
    <link href="assets/css/main.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- =======================================================
  * Template Name: Medilab
  * Template URL: https://bootstrapmade.com/medilab-free-medical-bootstrap-theme/
  * Updated: Aug 07 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="index-page">

    <?php include("_include/Header.inc.php"); ?>
    <main class="main">

        <!-- Page Title -->
        <div class="page-title position-relative" data-aos="fade" style="background-image: url(assets/img/title-banner.jpg);">
            <div class="container position-relative">
                <h1>Gallery <br></h1>
                <nav class="breadcrumbs">
                    <ol>
                        <li><a href="index.php"><i class="fa-solid fa-house "></i> Home</a></li>
                        <li class="current">Gallery</li>
                    </ol>
                </nav>
            </div>
        </div><!-- End Page Title -->
        <!-- Gallery Section -->
        <section id="gallery" class="gallery section">
            <div class="container title-section" data-aos="fade-up">
                <div class="row department-heading">
                    <div class="col-lg-6 col-sm-12 col-md-12 mb-4">
                        <h4> <span><i class="fa-solid fa-graduation-cap pe-2"></i>Our Gallery</span></h4>

                        <h2>A <span> glimpse</span> into <span>campus </span> life</h2>
                    </div>
                </div>
            </div>

            <div class="container" data-aos="fade-up" data-aos-delay="100">
                <div class="row">
                    <div class="">
                        <div class="row g-0 ">

                            <div class="col-lg-3 col-md-4 p-2">
                                <div class="gallery-item">
                                    <img src="assets/img/gallery/gallery-1.jpg" alt="" class="img-fluid">
                                    <div class="overlay">
                                        <a href="album.php" class="icon-link">
                                            <i class="fa-solid fa-plus"></i>
                                        </a>
                                    </div>
                                </div>
                            </div><!-- End Gallery Item -->

                            <div class="col-lg-3 col-md-4 p-2">
                                <div class="gallery-item">
                                    <img src="assets/img/gallery/gallery-2.jpg" alt="" class="img-fluid">
                                    <div class="overlay">
                                        <a href="album.php" class="icon-link">
                                            <i class="fa-solid fa-plus"></i>
                                        </a>
                                    </div>
                                </div>
                            </div><!-- End Gallery Item -->

                            <div class="col-lg-3 col-md-4 p-2">
                                <div class="gallery-item">
                                    <img src="assets/img/gallery/gallery-3.jpg" alt="" class="img-fluid">
                                    <div class="overlay">
                                        <a href="album.php" class="icon-link">
                                            <i class="fa-solid fa-plus"></i>
                                        </a>
                                    </div>
                                </div>
                            </div><!-- End Gallery Item -->

                            <div class="col-lg-3 col-md-4 p-2">
                                <div class="gallery-item">
                                    <img src="assets/img/gallery/gallery-4.jpg" alt="" class="img-fluid">
                                    <div class="overlay">
                                        <a href="album.php" class="icon-link">
                                            <i class="fa-solid fa-plus"></i>
                                        </a>
                                    </div>
                                </div>
                            </div><!-- End Gallery Item -->
                            <div class="col-lg-3 col-md-4 p-2">
                                <div class="gallery-item">
                                    <img src="assets/img/gallery/gallery-5.jpg" alt="" class="img-fluid">
                                    <div class="overlay">
                                        <a href="album.php" class="icon-link">
                                            <i class="fa-solid fa-plus"></i>
                                        </a>
                                    </div>
                                </div>
                            </div><!-- End Gallery Item -->

                            <div class="col-lg-3 col-md-4 p-2">
                                <div class="gallery-item">
                                    <img src="assets/img/gallery/gallery-6.jpg" alt="" class="img-fluid">
                                    <div class="overlay">
                                        <a href="album.php" class="icon-link">
                                            <i class="fa-solid fa-plus"></i>
                                        </a>
                                    </div>
                                </div>
                            </div><!-- End Gallery Item -->

                            <div class="col-lg-3 col-md-4 p-2">
                                <div class="gallery-item">
                                    <img src="assets/img/gallery/gallery-7.jpg" alt="" class="img-fluid">
                                    <div class="overlay">
                                        <a href="album.php" class="icon-link">
                                            <i class="fa-solid fa-plus"></i>
                                        </a>
                                    </div>
                                </div>
                            </div><!-- End Gallery Item -->

                            <div class="col-lg-3 col-md-4 p-2">
                                <div class="gallery-item">
                                    <img src="assets/img/gallery/gallery-8.jpg" alt="" class="img-fluid">

                                    <div class="overlay">
                                        <a href="album.php" class="icon-link">
                                            <i class="fa-solid fa-plus"></i>
                                        </a>
                                    </div>
                                </div>
                            </div><!-- End Gallery Item -->

                        </div>
                    </div>
                </div>
            </div>
        </section><!-- /Gallery Section -->
    </main>

    <?php include("_include/Footer.inc.php"); ?>

    <!-- Scroll Top -->
    <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>



    <!-- Vendor JS Files -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/fontawesome/js/all.min.js"></script>
    <!-- Main JS File -->
    <script src="assets/js/main.js"></script>

</body>

</html>