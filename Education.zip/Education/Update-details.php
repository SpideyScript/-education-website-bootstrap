<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta name="description" content="Welcome To SMIT">
  <meta name="keywords" content="HTML5 Template">
  <meta name="author" content="Smit.com">
  <title>Updates - SMIT</title>
  <!-- Favicons -->
  <link href="assets/img/favicon" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
    rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/fontawesome/css/all.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">

  <!-- =======================================================
  * Template Name: Medilab
  * Template URL: https://bootstrapmade.com/medilab-free-medical-bootstrap-theme/
  * Updated: Aug 07 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="index-page">

  <?php include("_include/Header.inc.php"); ?>
  <main class="main">
    <!-- Page Title -->
    <div class="page-title position-relative" data-aos="fade" style="background-image: url(assets/img/title-banner.jpg);">
      <div class="container position-relative">
        <h1>Updates<br></h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.php"><i class="fa-solid fa-house "></i> Home</a></li>
            <li class="current">Updates</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <section class="info">
      <div class="container">
        <div class="row">
          <div class="col-lg-9">
            <div class="event">
              <div class="single-event">
                <div class="row">
                  <div class="col-lg-3 col-sm-12 col-md-12 p-0">
                    <a href="Update-details.php">
                      <img src="assets/img/event.jpg" alt="" class="img-fluid">
                    </a>
                  </div>
                  <div class="col-lg-9 col-sm-12 col-md-12 event-content ">
                    <ul>
                      <li><i class="fa-solid fa-calendar-days"></i>January 18,2024</li>
                      <li></li>
                    </ul>
                    <a href="Update-details.php">
                      <h3>Comprehensive literacy and reading recovery conference</h3>
                    </a>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Labore tenetur deleniti culpa dignissimos voluptatum modi iure at temporibus aliquam vero, doloribus voluptatem dolore rem quasi perspiciatis eos facilis? Aut, consequuntur?</p>
                    <div class="d-flex align-items-end justify-content-end">
                      <a href="Update-details.php" role="button" class="btn event-btn">
                        View Details <i class="fa-solid fa-arrow-right"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div class="single-event">
                <div class="row">
                  <div class="col-lg-3 col-sm-12 col-md-12 p-0">
                    <a href="Update-details.php">
                      <img src="assets/img/event.jpg" alt="" class="img-fluid">
                    </a>
                  </div>
                  <div class="col-lg-9 col-sm-12 col-md-12 event-content ">
                    <ul>
                      <li><i class="fa-solid fa-calendar-days"></i>January 18,2024</li>
                      <li></li>
                    </ul>
                    <a href="Update-details.php">
                      <h3>Comprehensive literacy and reading recovery conference</h3>
                    </a>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Labore tenetur deleniti culpa dignissimos voluptatum modi iure at temporibus aliquam vero, doloribus voluptatem dolore rem quasi perspiciatis eos facilis? Aut, consequuntur?</p>
                    <div class="d-flex align-items-end justify-content-end">
                      <a href="Update-details.php" role="button" class="btn event-btn">
                        View Details <i class="fa-solid fa-arrow-right"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div class="single-event">
                <div class="row">
                  <div class="col-lg-3 col-sm-12 col-md-12 p-0">
                    <a href="Update-details.php">
                      <img src="assets/img/event.jpg" alt="" class="img-fluid">
                    </a>
                  </div>
                  <div class="col-lg-9 col-sm-12 col-md-12 event-content ">
                    <ul>
                      <li><i class="fa-solid fa-calendar-days"></i>January 18,2024</li>
                      <li></li>
                    </ul>
                    <a href="Update-details.php">
                      <h3>Comprehensive literacy and reading recovery conference</h3>
                    </a>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Labore tenetur deleniti culpa dignissimos voluptatum modi iure at temporibus aliquam vero, doloribus voluptatem dolore rem quasi perspiciatis eos facilis? Aut, consequuntur?</p>
                    <div class="d-flex align-items-end justify-content-end">
                      <a href="Update-details.php" role="button" class="btn event-btn">
                        View Details <i class="fa-solid fa-arrow-right"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div class="single-event">
                <div class="row">
                  <div class="col-lg-3 col-sm-12 col-md-12 p-0">
                    <a href="Update-details.php">
                      <img src="assets/img/event.jpg" alt="" class="img-fluid">
                    </a>
                  </div>
                  <div class="col-lg-9 col-sm-12 col-md-12 event-content ">
                    <ul>
                      <li><i class="fa-solid fa-calendar-days"></i>January 18,2024</li>
                      <li></li>
                    </ul>
                    <a href="Update-details.php">
                      <h3>Comprehensive literacy and reading recovery conference</h3>
                    </a>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Labore tenetur deleniti culpa dignissimos voluptatum modi iure at temporibus aliquam vero, doloribus voluptatem dolore rem quasi perspiciatis eos facilis? Aut, consequuntur?</p>
                    <div class="d-flex align-items-end justify-content-end">
                      <a href="Update-details.php" role="button" class="btn event-btn">
                        View Details <i class="fa-solid fa-arrow-right"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3">
            <?php include("_include/Sidebar.inc.php"); ?>
          </div>
        </div>
      </div>
    </section>
  </main>
  <?php include("_include/Footer.inc.php"); ?>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>



  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/fontawesome/js/all.min.js"></script>
  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" ></script>

</body>

</html>