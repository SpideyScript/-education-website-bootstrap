<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta name="description" content="Welcome To SMIT">
  <meta name="keywords" content="HTML5 Template">
  <meta name="author" content="Smit.com">
  <title>Home - SMIT</title>
  <!-- Favicons -->
  <link href="assets/img/favicon" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
    rel="stylesheet">

  <!-- Owl Carousel CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

  <!-- FontAwesome CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

  <link href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css" rel="stylesheet">
  <!-- Add these in your <head> section -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" />
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css" />
  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">


  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">


  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">

  <!-- =======================================================
  * Template Name: Medilab
  * Template URL: https://bootstrapmade.com/medilab-free-medical-bootstrap-theme/
  * Updated: Aug 07 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="index-page">

  <?php include("_include/Header.inc.php"); ?>

  <main class="main">
    <!-- Hero Section -->
    <section class="slider-02 banner-02 p-0">
      <div id="main-slider" class="swiper main-slider">
        <div class="swiper-wrapper">
          <!-- Slide 1 -->
          <div class="swiper-slide">
            <section id="hero" class="hero section dark-background">
              <!-- Add an overlay div with a dark filter on the image -->
              <div class="image-overlay"></div>
              <img src="assets/img/slider-1.jpg" alt="" class="dimmed-image">
              <div class="container">
                <div class="row">
                  <div class="col-lg-7 d-flex flex-column align-items-center align-items-lg-start banner-text">
                    <h5 class="bright-text" data-aos="fade-up" data-aos-delay="100" data-animation="fadeInDown" data-delay=".25s" style="animation-delay: 0.25s;">
                      WELCOME TO SMIT
                    </h5>
                    <h1 class="bright-text" data-aos="fade-up" data-aos-delay="200" data-animation="fadeInDown" data-delay=".5s" style="animation-delay: 0.5s;">
                      Start Your Beautiful and <span>Bright</span> Future
                    </h1>
                  </div>
                </div>
              </div>
            </section>
          </div>

          <div class="swiper-slide">
            <section id="hero" class="hero section dark-background">
              <!-- Add an overlay div with a dark filter on the image -->
              <div class="image-overlay"></div>
              <img src="assets/img/slider-2.jpg" alt="" class="dimmed-image">
              <div class="container">
                <div class="row">
                  <div class="col-lg-7 d-flex flex-column align-items-center align-items-lg-start banner-text">
                    <h5 class="bright-text" data-aos="fade-up" data-aos-delay="100" data-animation="fadeInDown" data-delay=".25s" style="animation-delay: 0.25s;">
                      WELCOME TO SMIT
                    </h5>
                    <h1 class="bright-text" data-aos="fade-up" data-aos-delay="200" data-animation="fadeInDown" data-delay=".5s" style="animation-delay: 0.5s;">
                      Start Your Beautiful and <span>Bright</span> Future
                    </h1>
                  </div>
                </div>
              </div>
            </section>
          </div>
          <div class="swiper-slide">
            <section id="hero" class="hero section dark-background">
              <!-- Add an overlay div with a dark filter on the image -->
              <div class="image-overlay"></div>
              <img src="assets/img/slider-3.webp" alt="" class="dimmed-image">
              <div class="container">
                <div class="row">
                  <div class="col-lg-7 d-flex flex-column align-items-center align-items-lg-start banner-text">
                    <h5 class="bright-text" data-aos="fade-up" data-aos-delay="100" data-animation="fadeInDown" data-delay=".25s" style="animation-delay: 0.25s;">
                      WELCOME TO SMIT
                    </h5>
                    <h1 class="bright-text" data-aos="fade-up" data-aos-delay="200" data-animation="fadeInDown" data-delay=".5s" style="animation-delay: 0.5s;">
                      Start Your Beautiful and <span>Bright</span> Future
                    </h1>
                  </div>
                </div>
              </div>
            </section>
          </div>
          <!-- Add more slides as needed -->
        </div>

        <!-- Slider Navigation -->
        <div class="swiper-button-prev" tabindex="0" role="button" aria-label="Previous slide"></div>
        <div class="swiper-button-next" tabindex="0" role="button" aria-label="Next slide"></div>
      </div>

    </section>
    <div class="container-fluid" style="background-color: #e1e3ff;">
      <div class="row">
        <div class="col-lg-9 ms-auto col-md-12 col-sm-12">
          <div class="row m-0">
            <div class="box-icon col-lg-3 col-md-12 ">
              <div class="d-flex ">
                <div class="feature-icon">
                  <img src="assets/img/icon/2.svg" alt="icon">
                </div>
                <span class="count">01</span>

              </div>
              <div class="feature-title">
                <h3> AFFILATED TO BPUT ROURKELA</h3>
              </div>
            </div>
            <div class="box-icon col-lg-3 col-md-12 col-sm-12">
              <div class="d-flex">
                <div class="feature-icon">
                  <img src="assets/img/icon/3.svg" alt="icon">
                </div>
                <span class="count">02</span>

              </div>
              <div class="feature-title">
                <h3> APPROVED BY AICTE NEW DELHI</h3>
              </div>
            </div>
            <div class="box-icon col-lg-3 col-md-12">
              <div class="d-flex">
                <div class="feature-icon">
                  <img src="assets/img/icon/4.svg" alt="icon">
                </div>
                <span class="count">03</span>

              </div>
              <div class="feature-title">
                <h3> ADMISSION FOR 4 YEAR DEGREE</h3>
              </div>
            </div>
            <div class="box-icon col-lg-3 col-md-12 col-sm-12">
              <div class="d-flex">
                <div class="feature-icon">
                  <img src="assets/img/icon/1.svg" alt="icon">

                </div>
                <span class="count">04</span>

              </div>
              <div class="feature-title">
                <h3> SMIT ESTABLISHED FROM 1980</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


    <!-- About Section -->
    <section id="about" class="about section p-realtive">
      <div class="container">
        <div class="row gy-4 gx-5">
          <div class="col-lg-6 content col-sm-12 col-md-12" data-aos="fade-up" data-aos-delay="100">
            <div class="title-heading">
              <h3>ABOUT US</h3>
            </div>
            <p>
              Established in 1980, the Sanjay Memorial Institute of Technology (SMIT) has been at the forefront of engineering education in Berhampur, Orissa. As the pioneering institution affiliated with the esteemed Biju Patnaik University of Technology (BPUT) and approved by AICTE, New Delhi, SMIT has carved a niche for itself in the domain of technical education. Our campus, a cradle of innovation and excellence, offers a rich tapestry of learning experiences across seven departments including Civil Engineering, Computer Science Engineering, Electrical and Electronics Engineering, Mechanical Engineering, Electrical Engineering, Electronics & Telecommunications, and Basic Science & Humanities.

              At SMIT, we believe in creating an ecosystems that nurtures talent, fosters intellectual growth, and hones the skills of future engineers. Our comprehensive facilities rangin.
            </p>
          </div>

          <div class="col-lg-6 align-self-start  col-sm-12 col-md-12">
            <img src="assets/img/about-us.jpg" class="img-fluid" alt="">
          </div>
        </div>
      </div>
    </section>
    <section class="department-area" style="background-color: #F2F3F5;">
      <div class="container">
        <div class="row department-heading">
          <div class="col-lg-6 col-sm-12 col-md-12 mb-4">
            <h4> <span><i class="fa-solid fa-graduation-cap pe-2"></i>Our Courses</span></h4>

            <h2> Academic <span> opportunities </span>that we provide</h2>
          </div>
        </div>
        <div class="department-slider ">
          <div class="row" id="getCourse">

            <!-- <div class="col-lg-3 col-sm-12 col-md-12">
              <div class="department-item ">
                <div class="department-icon">
                  <img src="assets/img/icon/mechanical.svg" alt="">
                </div>
                <div class="department-info">
                  <h4 class="department-title"> Mechanical Engineering </h4>
                  <p>There are many variations of passages the majority have some injected humour.</p>

                </div>
                <div class="department-btn">
                  <a href="">View Details <i class="fa-solid fa-arrow-right ps-1"></i></a>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-12 col-md-12">
              <div class="department-item ">
                <div class="department-icon">
                  <img src="assets/img/icon/civil.svg" alt="">
                </div>
                <div class="department-info">
                  <h4 class="department-title">Civil Engineering</h4>
                  <p>There are many variations of passages the majority have some injected humour.</p>
                </div>
                <div class="department-btn">
                  <a href="">View Details <i class="fa-solid fa-arrow-right ps-1"></i></a>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-12 col-md-12">
              <div class="department-item ">
                <div class="department-icon">
                  <img src="assets/img/icon/bulb.svg" alt="">
                </div>
                <div class="department-info">
                  <h4 class="department-title">Electrical</h4>
                  <p>There are many variations of passages the majority have some injected humour.</p>
                  <div class="department-btn">
                    <a href=""></a>
                  </div>
                </div>
                <div class="department-btn">
                  <a href="">View Details <i class="fa-solid fa-arrow-right ps-1"></i></a>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-12 col-md-12">
              <div class="department-item ">
                <div class="department-icon">
                  <img src="assets/img/icon/electrician.svg" alt="">
                </div>
                <div class="department-info">
                  <h4 class="department-title">Electrical & Electronics Engineering</h4>
                  <p>There are many variations of passages the majority have some injected humour.</p>
                </div>
                <div class="department-btn">
                  <a href="">View Details <i class="fa-solid fa-arrow-right ps-1"></i></a>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-12 col-md-12">
              <div class="department-item ">
                <div class="department-icon">
                  <img src="assets/img/icon/telecom.svg" alt="">
                </div>
                <div class="department-info">
                  <h4 class="department-title">Electrical & Telecommunication</h4>
                  <p>There are many variations of passages the majority have some injected humour.</p>

                </div>
                <div class="department-btn">
                  <a href="">View Details <i class="fa-solid fa-arrow-right ps-1"></i></a>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-12 col-md-12">
              <div class="department-item ">
                <div class="department-icon">
                  <img src="assets/img/icon/computer.svg" alt="">
                </div>
                <div class="department-info">
                  <h4 class="department-title">Computer science & Engineering</h4>
                  <p>There are many variations of passages the majority have some injected humour.</p>
                </div>
                <div class="department-btn">
                  <a href="">View Details <i class="fa-solid fa-arrow-right ps-1"></i></a>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-12 col-md-12">
              <div class="department-item ">
                <div class="department-icon">
                  <img src="assets/img/icon/human.svg" alt="">
                </div>
                <div class="department-info">
                  <h4 class="department-title">Basic science & Humanity</h4>
                  <p>There are many variations of passages the majority have some injected humour.</p>
                </div>
                <div class="department-btn">
                  <a href="">View Details <i class="fa-solid fa-arrow-right ps-1"></i></a>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-12 col-md-12">
              <div class="department-item ">
                <div class="department-icon">
                  <img src="assets/img/icon/others.svg" alt="">
                </div>
                <div class="department-info">
                  <h4 class="department-title">Other Traning</h4>
                  <p>There are many variations of passages the majority have some injected humour.</p>

                </div>
                <div class="department-btn">
                  <a href="">View Details <i class="fa-solid fa-arrow-right ps-1"></i></a>
                </div>
              </div>
            </div> -->
          </div>

        </div>

      </div>
    </section>

    <section class="why-us">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="why-us-title mb-4">
              <h4> <span><i class="fa-solid fa-graduation-cap pe-2"></i>Why Choose Us</span></h4>
              <h2>We Are Expert & <span>Do Our Best</span> For Your Goal.</h2>
            </div>
            <div class="why-us-content">
              <div class="row">
                <div class="col-lg-6">
                  <div class="why-us-item">
                    <div class="why-us-icon">
                      <h5><i class="fa-solid fa-book-open-reader"></i></h5>
                    </div>
                    <div class="why-us-info">
                      <h4>Popular Courses</h4>
                      <p>There are many variation of the suffered.</p>
                    </div>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="why-us-item">
                    <div class="why-us-icon">
                      <h5><i class="fa-solid fa-users"></i></h5>
                    </div>
                    <div class="why-us-info">
                      <h4>Qualified Teachers</h4>
                      <p>There are many variation of the suffered.</p>
                    </div>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="why-us-item">
                    <div class="why-us-icon">
                      <h5><i class="fa-solid fa-magnifying-glass"></i></h5>
                    </div>
                    <div class="why-us-info">
                      <h4>Resource Center</h4>
                      <p>There are many variation of the suffered.</p>
                    </div>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="why-us-item">
                    <div class="why-us-icon">
                      <h5><i class="fa-solid fa-chalkboard-user"></i></h5>
                    </div>
                    <div class="why-us-info">
                      <h4>Training and Placement</h4>
                      <p>There are many variation of the suffered.</p>
                    </div>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="why-us-item">
                    <div class="why-us-icon">
                      <h5><i class="fa-solid fa-computer"></i></h5>
                    </div>
                    <div class="why-us-info">
                      <h4>Mordern Facilities</h4>
                      <p>There are many variation of the suffered.</p>
                    </div>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="why-us-item">
                    <div class="why-us-icon">
                      <h5><i class="fa-solid fa-hands-holding-circle"></i></h5>
                    </div>
                    <div class="why-us-info">
                      <h4>20+ Years Establishmetn</h4>
                      <p>There are many variation of the suffered.</p>
                    </div>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="why-us-item">
                    <div class="why-us-icon">
                      <h5><i class="fa-solid fa-building-columns"></i></h5>
                    </div>
                    <div class="why-us-info">
                      <h4>Infrastructure</h4>
                      <p>There are many variation of the suffered.</p>
                    </div>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="why-us-item">
                    <div class="why-us-icon">
                      <h5><i class="fa-solid fa-people-robbery"></i></h5>
                    </div>
                    <div class="why-us-info">
                      <h4>Extra-curricular Activities</h4>
                      <p>There are many variation of the suffered.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
          <div class="col-lg-6">
            <div class="managemnet-title">
              <h2><span>Our</span> Management</h2>
            </div>
            <div class="management-box">
              <div>
                <div class="management-item">
                  <div class="management-img">
                    <img src="https://pinnacle.works/wp-content/uploads/2022/06/dummy-image.jpg" alt="" class="img-fluid img-thumbnail">
                  </div>
                  <div class="management-info">
                    <h4>Dr. Bhagaban Gantayat</h4>
                    <p>PRINISIPAL</p>
                    <a href="#">READ MORE <i class="fa-solid fa-arrow-right ps-1"></i></a>
                  </div>

                </div>
                <div class="management-item">
                  <div class="management-img">
                    <img src="https://pinnacle.works/wp-content/uploads/2022/06/dummy-image.jpg" alt="" class="img-fluid img-thumbnail">
                  </div>
                  <div class="management-info">
                    <h4>Dr. Bhagaban Gantayat</h4>
                    <p>PRINISIPAL</p>
                    <a href="#">READ MORE <i class="fa-solid fa-arrow-right ps-1"></i></a>
                  </div>

                </div>
                <div class="management-item">
                  <div class="management-img">
                    <img src="https://pinnacle.works/wp-content/uploads/2022/06/dummy-image.jpg" alt="" class="img-fluid img-thumbnail">
                  </div>
                  <div class="management-info">
                    <h4>Dr. Bhagaban Gantayat</h4>
                    <p>PRINISIPAL</p>
                    <a href="#">READ MORE <i class="fa-solid fa-arrow-right ps-1"></i></a>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
    </section>

    <section class="facilty">
      <div class="container">
        <div class="row department-heading">
          <div class="col-lg-6 col-sm-12 col-md-12 mb-4">
            <h4> <span><i class="fa-solid fa-graduation-cap pe-2"></i>Our Facility</span></h4>

            <h2> Empowering<span> learning</span> with<span> advanced </span> facilities</h2>
          </div>
        </div>
        <div class="owl-carousel owl-theme" id="Facility">
          <div class="item">
            <div class="facility-item" data-wow-delay=".25s">
              <div class="facility-img">
                <img src="assets/img/facility/library.jpg" alt="">
                <a href="#" class="link-icon"><i class="fa-solid fa-link"></i></a>
              </div>
              <!-- <div class="facility-tag ">
                <span>30 Seat</span>
              </div> -->
              <div class="facility-title">
                <h3>Library</h3>

              </div>
            </div>
          </div>
          <div class="item">
            <div class="facility-item" data-wow-delay=".25s">
              <div class="facility-img">
                <img src="assets/img/facility/hostel.jpeg" alt="">
                <a href="#" class="link-icon"><i class="fa-solid fa-link"></i></a>
              </div>
              <div class="facility-title">
                <h3>Hostel</h3>

              </div>
            </div>
          </div>
          <div class="item">
            <div class="facility-item" data-wow-delay=".25s">
              <div class="facility-img">
                <img src="assets/img/facility/transport.webp" alt="">
                <a href="#" class="link-icon"><i class="fa-solid fa-link"></i></a>
              </div>
              
              <div class="facility-title">
                <h3>Transport</h3>

              </div>
            </div>
          </div>
          <div class="item">
            <div class="facility-item" data-wow-delay=".25s">
              <div class="facility-img">
                <img src="assets/img/facility/canteen.jpg" alt="">
                <a href="#" class="link-icon"><i class="fa-solid fa-link"></i></a>
              </div>
             
              <div class="facility-title">
                <h3> Canteen</h3>

              </div>
            </div>
          </div>
          <div class="item">
            <div class="facility-item" data-wow-delay=".25s">
              <div class="facility-img">
                <img src="assets/img/facility/computer-lab.jpg" alt="">
                <a href="#" class="link-icon"><i class="fa-solid fa-link"></i></a>
              </div>
              
              <div class="facility-title">
                <h3>Computer Lab</h3>

              </div>
            </div>
          </div>
          <div class="item">
            <div class="facility-item" data-wow-delay=".25s">
              <div class="facility-img">
                <img src="assets/img/facility/sports.avif" alt="">
                <a href="#" class="link-icon"><i class="fa-solid fa-link"></i></a>
              </div>
             
              <div class="facility-title">
                <h3>Sports Club</h3>

              </div>
            </div>
          </div>
          <div class="item">
            <div class="facility-item" data-wow-delay=".25s">
              <div class="facility-img">
                <img src="assets/img/facility/WifiCampus.jpg" alt="">
                <a href="#" class="link-icon"><i class="fa-solid fa-link"></i></a>
              </div>
             
              <div class="facility-title">
                <h3> Campus Internet</h3>

              </div>
            </div>
          </div>
          <div class="item">
            <div class="facility-item" data-wow-delay=".25s">
              <div class="facility-img">
                <img src="assets/img/facility/robotic.png" alt="">
                <a href="#" class="link-icon"><i class="fa-solid fa-link"></i></a>
              </div>
             
              <div class="facility-title">
                <h3>Robotic Club</h3>

              </div>
            </div>
          </div>
          <!-- Add more courses as needed -->
        </div>
      </div>
    </section>

    <!-- Stats Section -->
    <section id="stats" class="stats section py-5">
      <div class="container" data-aos="fade-up" data-aos-delay="100">
        <div class="row gy-4">

          <div class="col-lg-3 col-md-6 col-sm-6 d-flex flex-column align-items-center text-center">
            <div class="stats-item">
              <img src="assets/img/icon/intake.svg" alt="Intake Icon" class="img-fluid mb-3" style="width: 50px; height: auto;">
            </div>
            <div class="stats-desc">
              <span data-purecounter-start="0" data-purecounter-end="210" data-purecounter-duration="1"
                class="purecounter fs-3 fw-bold"></span>
              <p class="mb-0">Total Intake</p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6 col-sm-6 d-flex flex-column align-items-center text-center">
            <div class="stats-item">
              <img src="assets/img/icon/book.svg" alt="Book Icon" class="img-fluid mb-3" style="width: 50px; height: auto;">
            </div>
            <div class="stats-desc">
              <span data-purecounter-start="0" data-purecounter-end="7" data-purecounter-duration="1"
                class="purecounter fs-3 fw-bold"></span>
              <p class="mb-0">Department</p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6 col-sm-6 d-flex flex-column align-items-center text-center">
            <div class="stats-item">
              <img src="assets/img/icon/graduate.svg" alt="Graduate Icon" class="img-fluid mb-3" style="width: 50px; height: auto;">
            </div>
            <div class="stats-desc">
              <span data-purecounter-start="0" data-purecounter-end="25" data-purecounter-duration="1"
                class="purecounter fs-3 fw-bold"></span>
              <p class="mb-0">Year Old</p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6 col-sm-6 d-flex flex-column align-items-center text-center">
            <div class="stats-item">
              <img src="assets/img/icon/graduate-cap.svg" alt="Graduate Cap Icon" class="img-fluid mb-3" style="width: 50px; height: auto;">
            </div>
            <div class="stats-desc">
              <span data-purecounter-start="0" data-purecounter-end="5000" data-purecounter-duration="1"
                class="purecounter fs-3 fw-bold"></span>
              <p class="mb-0">& More Graduates</p>
            </div>
          </div><!-- End Stats Item -->

        </div>
      </div>
    </section>


    <!-- Gallery Section -->
    <section id="gallery" class="gallery section">
      <div class="container title-section" data-aos="fade-up">
        <div class="row department-heading">
          <div class="col-lg-6 col-sm-12 col-md-12 mb-4">
            <h4> <span><i class="fa-solid fa-graduation-cap pe-2"></i>Our Gallery</span></h4>

            <h2>A <span> glimpse</span> into <span>campus </span> life</h2>
          </div>
        </div>
      </div>


      <div class="container" data-aos="fade-up" data-aos-delay="100">
        <div class="row">
          <div class="col-lg-5 col-md-12">

            <div class="video-gallery">
              <img src="assets/img/video.jpg" alt="" data-aos="fade-in" class="video-img">

              <div class="container">
                <div class="row">
                  <div class="  ">
                    <a href="https://www.youtube.com/watch?v=Y7f98aduVJ8" class="glightbox pulsating-play-btn video-btn"></a>
                  </div>
                </div>
              </div>
            </div>
          </div>



          <div class="col-lg-7">
            <div class="row g-0 ">

              <div class="col-lg-4 col-md-4">
                <div class="gallery-item">
                  <a href="assets/img/gallery/gallery-1.jpg" class="glightbox" data-gallery="images-gallery">
                    <img src="assets/img/gallery/gallery-1.jpg" alt="" class="img-fluid">
                  </a>
                </div>
              </div><!-- End Gallery Item -->

              <div class="col-lg-4 col-md-4">
                <div class="gallery-item">
                  <a href="assets/img/gallery/gallery-2.jpg" class="glightbox" data-gallery="images-gallery">
                    <img src="assets/img/gallery/gallery-2.jpg" alt="" class="img-fluid">
                  </a>
                </div>
              </div><!-- End Gallery Item -->

              <div class="col-lg-4 col-md-4">
                <div class="gallery-item">
                  <a href="assets/img/gallery/gallery-3.jpg" class="glightbox" data-gallery="images-gallery">
                    <img src="assets/img/gallery/gallery-3.jpg" alt="" class="img-fluid">
                  </a>
                </div>
              </div><!-- End Gallery Item -->
            </div>
            <div class="row g-0">
              <div class="col-lg-6 col-md-4">
                <div class="gallery-item">
                  <a href="assets/img/gallery/gallery-7.jpg" class="glightbox" data-gallery="images-gallery">
                    <img src="assets/img/gallery/gallery-7.jpg" alt="" class="img-fluid">
                  </a>
                </div>
              </div><!-- End Gallery Item -->
              <div class="col-lg-6">
                <div class="row g-0">
                  <div class="col-lg-6 col-md-4">
                    <div class="gallery-item">
                      <a href="assets/img/gallery/gallery-4.jpg" class="glightbox" data-gallery="images-gallery">
                        <img src="assets/img/gallery/gallery-4.jpg" alt="" class="img-fluid">
                      </a>
                    </div>
                  </div><!-- End Gallery Item -->

                  <div class="col-lg-6 col-md-4">
                    <div class="gallery-item">
                      <a href="assets/img/gallery/gallery-5.jpg" class="glightbox" data-gallery="images-gallery">
                        <img src="assets/img/gallery/gallery-5.jpg" alt="" class="img-fluid">
                      </a>
                    </div>
                  </div><!-- End Gallery Item -->
                </div>

                <div class="row g-0">
                  <div class="col-lg-6 col-md-4">
                    <div class="gallery-item">
                      <a href="assets/img/gallery/gallery-6.jpg" class="glightbox" data-gallery="images-gallery">
                        <img src="assets/img/gallery/gallery-6.jpg" alt="" class="img-fluid">
                      </a>
                    </div>
                  </div><!-- End Gallery Item -->

                  <div class="col-lg-6 col-md-4">
                    <div class="gallery-item">
                      <a href="assets/img/gallery/gallery-7.jpg" class="glightbox" data-gallery="images-gallery">
                        <img src="assets/img/gallery/gallery-7.jpg" alt="" class="img-fluid">
                      </a>
                    </div>
                  </div><!-- End Gallery Item -->
                </div>
              </div>


            </div>

          </div>
        </div>

      </div>

    </section><!-- /Gallery Section -->
    <section class="event">
      <div class="container-fluid">
        <div class="container title-section" data-aos="fade-up">
          <div class="row department-heading">
            <div class="col-lg-6 col-sm-12 col-md-12 mb-4">
              <h4>
                <span><i class="fa-solid fa-graduation-cap pe-2"></i>Latest Updates</span>
              </h4>
              <h2> Stay <span> Informed</span> with <span>Updates</span> </h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-6 col-sm-6 col-md-6 ps-5">
            <div class="slider" id="updatesList">
              <!-- <div class="single-event">
                <div class="row">
                  <div class="col-lg-4 col-sm-12 col-md-12">
                    <a href="Updates.php">
                      <img src="assets/img/event.jpg" alt="" class="img-fluid">
                    </a>
                  </div>
                  <div class="event-content col-lg-8 col-sm-12 col-md-12">
                    <ul>
                      <li><i class="fa-solid fa-calendar-days"></i>January 18,2024</li>
                      <li></li>
                    </ul>
                    <a href="Update-details.php">
                      <h3>Comprehensive literacy and reading recovery conference</h3>

                    </a>
                    <div class="d-flex align-items-end justify-content-end">
                      <a href="Updates.php" role="button" class="btn event-btn">
                        View More <i class="fa-solid fa-arrow-right"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div class="single-event">
                <div class="row">
                  <div class="col-lg-4 col-sm-12 col-md-12 p-0">
                    <a href="Updates.php">
                      <img src="assets/img/event.jpg" alt="" class="img-fluid">
                    </a>
                  </div>
                  <div class="event-content col-lg-8 col-sm-12 col-md-12">
                    <ul>
                      <li><i class="fa-solid fa-calendar-days"></i>January 18,2024</li>
                      <li></li>
                    </ul>
                    <a href="Update-details.php">
                      <h3>Comprehensive literacy and reading recovery conference</h3>

                    </a>
                    <div class="d-flex align-items-end justify-content-end">
                      <a href="Updates.php" role="button" class="btn event-btn">
                        View More <i class="fa-solid fa-arrow-right"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div class="single-event">
                <div class="row">
                  <div class="col-lg-4 col-sm-12 col-md-12 p-0">
                    <a href="Updates.php">
                      <img src="assets/img/event.jpg" alt="" class="img-fluid">
                    </a>
                  </div>
                  <div class="event-content col-lg-8 col-sm-12 col-md-12">
                    <ul>
                      <li><i class="fa-solid fa-calendar-days"></i>January 18,2024</li>
                      <li></li>
                    </ul>
                    <a href="Update-details.php">
                      <h3>Comprehensive literacy and reading recovery conference</h3>

                    </a>
                    <div class="d-flex align-items-end justify-content-end">
                      <a href="Updates.php" role="button" class="btn event-btn">
                        View More <i class="fa-solid fa-arrow-right"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div class="single-event">
                <div class="row">
                  <div class="col-lg-4 col-sm-12 col-md-12 p-0">
                    <a href="Updates.php">
                      <img src="assets/img/event.jpg" alt="" class="img-fluid">
                    </a>
                  </div>
                  <div class="event-content col-lg-8 col-sm-12 col-md-12">
                    <ul>
                      <li><i class="fa-solid fa-calendar-days"></i>January 18,2024</li>
                      <li></li>
                    </ul>
                    <a href="Update-details.php">
                      <h3>Comprehensive literacy and reading recovery conference</h3>

                    </a>
                    <div class="d-flex align-items-end justify-content-end">
                      <a href="Updates.php" role="button" class="btn event-btn">
                        View More <i class="fa-solid fa-arrow-right"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div> -->
            </div>
            <div class="col-lg-12 col-sm-12 col-md-12 p-0">
              <a href="Updates.php" class="view-all-link">View All</a>
            </div>
          </div>
          <div class="col-lg-6 col-sm-6 col-md-6 mt-5">
            <div class="event-img">
              <img src="assets/img/event-img-5.png" alt="" class="img-fluid">
              <div class="event-shape-1 rotated">
                <img src="assets/img/event-shape-1.png" alt="">
              </div>
              <div class="event-shape-2">
                <img src="assets/img/event-shape-2.png" alt="">
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="enroll-area">
      <div class="container">
        <div class="row ">
          <div class="col-lg-7 col-md-12 col-sm-12 ps-4 mt-5">
            <div class="placement-title mb-4">
              <h4> <span><i class="fa-solid fa-graduation-cap pe-2"></i>Placement Statics</span></h4>
              <h2>Guaranteed <span>placement & career</span> success.</h2>
            </div>
            <div class="row">

              <div class="col-lg-6 col-sm-12 col-md-12 ">
                <div class="award-card ">
                  <div class="award-icon">
                    <img src="assets/img/icon/10.svg" alt="icon">
                  </div>
                  <div class="award-content">
                    <h3> GOLD AWARD CCQC-2013 Rourkela</h3>
                    <p></p>
                  </div>
                </div>
                <div class="award-card ">
                  <div class="award-icon">
                    <img src="assets/img/icon/5.svg" alt="icon">
                  </div>
                  <div class="award-content">
                    <h3>CALCUTTA SPRINGS LTD.</h3>
                    <p></p>
                  </div>
                </div>
                <div class="award-card ">
                  <div class="award-icon">
                    <img src="assets/img/icon/13.svg" alt="icon">
                  </div>
                  <div class="award-content">
                    <h3> QUARTEZ TECHNOLOGY</h3>
                    <p></p>
                  </div>
                </div>
              </div>
              <div class="col-lg-6 col-sm-12 col-md-12">
                <div class="award-card ">
                  <div class="award-icon">
                    <img src="assets/img/icon/10.svg" alt="icon">
                  </div>
                  <div class="award-content">
                    <h3> GOLD AWARD CCQC-2012 Rourkela</h3>
                    <p></p>
                  </div>
                </div>
                <div class="award-card ">
                  <div class="award-icon">
                    <img src="assets/img/icon/11.svg" alt="icon">
                  </div>
                  <div class="award-content">
                    <h3>NEOFRAWEB</h3>
                    <p></p>
                  </div>
                </div>
                <div class="award-card ">
                  <div class="award-icon ">
                    <img src="assets/img/icon/14.svg" alt="icon">
                  </div>
                  <div class="award-content">
                    <h3>SIMPLEX</h3>
                    <p></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-5 col-md-12 col-sm-12">
            <div class="enroll-form-header">
              <h3>Request Information</h3>
            </div>
            <div class="enroll-form">

              <form action="">
                <div class="form-group ">
                  <input type="text" class="form-control" id="name" placeholder="Enter your name">
                </div>
                <div class="form-group">
                  <input type="email" class="form-control" id="email" placeholder="Enter your email">
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" id="email" placeholder="Enter your phone">
                </div>
                <div class="row">
                  <div class="form-group col-lg-6 col-md-6 col-sm-6">
                    <select class="form-select" id="exampleSelect" aria-label="Default select example">
                      <option selected>Select an option</option>
                      <option value="1">Option 1</option>
                      <option value="2">Option 2</option>
                      <option value="3">Option 3</option>
                    </select>
                  </div>
                  <div class="form-group col-lg-6 col-md-6 col-sm-6">
                    <input type="text" class="form-control" id="flatpickr" placeholder="Select a date">
                  </div>
                </div>
                <div class="form-group">
                  <textarea class="form-control" id="basicTextarea" rows="3" placeholder="Enter your text here"></textarea>
                </div>
                <div class="submit-button mt-3">
                  <button type="submit" class="theme-btn">Submit <i class="fa-solid fa-arrow-right ps-2"></i></button>
                </div>
              </form>
            </div>
          </div>

        </div>
      </div>
    </section>




    <!-- Testimonials Section -->
    <diV id="testimonials" class="testimonials section">

      <div class="container">

        <div class="row align-items-center">

          <div class="col-lg-5 col-md-12  col-sm-12 info testimonial-title" data-aos="fade-up" data-aos-delay="100">
            <div class="placement-title mb-4">
              <h4> <span><i class="fa-solid fa-graduation-cap pe-2"></i>Testimonials</span></h4>

              <h2>What Others<span> Say's</span> </h2>
            </div>
          </div>

          <div class="col-lg-7 col-md-12 col-sm-12" data-aos="fade-up" data-aos-delay="200">

            <div class="swiper init-swiper">
              <script type="application/json" class="swiper-config">
                {
                  "loop": true,
                  "speed": 600,
                  "autoplay": {
                    "delay": 5000
                  },
                  "slidesPerView": "auto",
                  "pagination": {
                    "el": ".swiper-pagination",
                    "type": "bullets",
                    "clickable": true
                  }
                }
              </script>
              <div class="swiper-wrapper" id="testimonialList">
              <!-- 
                <div class="swiper-slide">
                  <div class="testimonial-item">
                    <div class="d-flex">
                      <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img flex-shrink-0"
                        alt="">
                      <div>
                        <h3>Saul Goodman</h3>
                        <h4>Ceo &amp; Founder</h4>
                        <div class="stars">
                          <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                            class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                        </div>
                      </div>
                    </div>
                    <p>
                      <i class="bi bi-quote quote-icon-left"></i>
                      <span>Proin iaculis purus consequat sem cure digni ssim donec porttitora entum suscipit rhoncus.
                        Accusantium quam, ultricies eget id, aliquam eget nibh et. Maecen aliquam, risus at
                        semper.</span>
                      <i class="bi bi-quote quote-icon-right"></i>
                    </p>
                  </div>
                </div>

                <div class="swiper-slide">
                  <div class="testimonial-item">
                    <div class="d-flex">
                      <img src="assets/img/testimonials/testimonials-2.jpg" class="testimonial-img flex-shrink-0"
                        alt="">
                      <div>
                        <h3>Sara Wilsson</h3>
                        <h4>Designer</h4>
                        <div class="stars">
                          <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                            class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                        </div>
                      </div>
                    </div>
                    <p>
                      <i class="bi bi-quote quote-icon-left"></i>
                      <span>Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid cillum
                        eram malis quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim
                        culpa.</span>
                      <i class="bi bi-quote quote-icon-right"></i>
                    </p>
                  </div>
                </div>

                <div class="swiper-slide">
                  <div class="testimonial-item">
                    <div class="d-flex">
                      <img src="assets/img/testimonials/testimonials-3.jpg" class="testimonial-img flex-shrink-0"
                        alt="">
                      <div>
                        <h3>Jena Karlis</h3>
                        <h4>Store Owner</h4>
                        <div class="stars">
                          <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                            class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                        </div>
                      </div>
                    </div>
                    <p>
                      <i class="bi bi-quote quote-icon-left"></i>
                      <span>Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem veniam duis
                        minim tempor labore quem eram duis noster aute amet eram fore quis sint minim.</span>
                      <i class="bi bi-quote quote-icon-right"></i>
                    </p>
                  </div>
                </div>

                <div class="swiper-slide">
                  <div class="testimonial-item">
                    <div class="d-flex">
                      <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img flex-shrink-0"
                        alt="">
                      <div>
                        <h3>Matt Brandon</h3>
                        <h4>Freelancer</h4>
                        <div class="stars">
                          <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                            class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                        </div>
                      </div>
                    </div>
                    <p>
                      <i class="bi bi-quote quote-icon-left"></i>
                      <span>Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim fugiat minim
                        velit minim dolor enim duis veniam ipsum anim magna sunt elit fore quem dolore labore illum
                        veniam.</span>
                      <i class="bi bi-quote quote-icon-right"></i>
                    </p>
                  </div>
                </div>

                <div class="swiper-slide">
                  <div class="testimonial-item">
                    <div class="d-flex">
                      <img src="assets/img/testimonials/testimonials-5.jpg" class="testimonial-img flex-shrink-0"
                        alt="">
                      <div>
                        <h3>John Larson</h3>
                        <h4>Entrepreneur</h4>
                        <div class="stars">
                          <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                            class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                        </div>
                      </div>
                    </div>
                    <p>
                      <i class="bi bi-quote quote-icon-left"></i>
                      <span>Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster veniam
                        enim culpa labore duis sunt culpa nulla illum cillum fugiat legam esse veniam culpa fore nisi
                        cillum quid.</span>
                      <i class="bi bi-quote quote-icon-right"></i>
                    </p>
                  </div>
                </div> -->

              </div>

            </div>

          </div>

        </div>

      </div>

    </div><!-- /Testimonials Section -->


    <section id="clients" class="clients section light-background">
      <div class="container" data-aos="zoom-in">

        <!-- Swiper Container -->
        <div class="swiper-container">
          <div class="swiper-wrapper align-items-center ">
            <div class="swiper-slide">
              <img src="assets/img/clients/client-1.png" class="img-fluid" alt="">
            </div>
            <div class="swiper-slide">
              <img src="assets/img/clients/client-2.png" class="img-fluid" alt="">
            </div>
            <div class="swiper-slide">
              <img src="assets/img/clients/client-3.png" class="img-fluid" alt="">
            </div>
            <div class="swiper-slide">
              <img src="assets/img/clients/client-4.png" class="img-fluid" alt="">
            </div>
            <div class="swiper-slide">
              <img src="assets/img/clients/client-5.png" class="img-fluid" alt="">
            </div>
            <div class="swiper-slide">
              <img src="assets/img/clients/client-6.png" class="img-fluid" alt="">
            </div>
            <div class="swiper-slide">
              <img src="assets/img/clients/client-7.png" class="img-fluid" alt="">
            </div>
            <div class="swiper-slide">
              <img src="assets/img/clients/client-8.png" class="img-fluid" alt="">
            </div>
          </div>
          <!-- Pagination -->

        </div>

      </div>
    </section><!-- /Clients Section -->
  </main>
  <?php include("_include/Footer.inc.php"); ?>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>



  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/fontawesome/js/all.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
  <!-- Owl Carousel JS -->
  <script src="assets/vendor/Owl-Carousel/owl.carousel.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
  <!-- Main JS File -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

  <script src="assets/js/main.js"></script>
  <script src="assets/js/APIURL.js"></script>
  <script>
    $(document).ready(function() {
      scrollingNews();
      getUpdate();
      getTestimonial();
    });

    function getUpdate() {
      const tenant_id = '1';

      $.ajax({
        type: "GET",
        url: `${API_URL}/Updates/List/${tenant_id}`,
        dataType: "json",
        success: function(response) {
          // console.log(response);

          let list = response.data;
          $('#updatesList').empty(); // Clear existing content

          $.each(list, function(index, val) {
            let row = `
          <div class="single-event">
            <div class="row">
              <div class="col-lg-4 col-sm-12 col-md-12">
                <a href="Updates.php">
                  <img src="${val.display_image}" alt="" class="img-fluid">
                </a>
              </div>
              <div class="event-content col-lg-8 col-sm-12 col-md-12">
                <ul>
                  <li><i class="fa-solid fa-calendar-days"></i>${val.event_date}</li>
                </ul>
                <a href="Update-details.php">
                  <h3>${val.title}</h3>
                </a>
                <div class="d-flex align-items-end justify-content-end">
                  <a href="Updates.php" role="button" class="btn event-btn">
                    View More <i class="fa-solid fa-arrow-right"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        `;
            $('#updatesList').append(row);
          });

          // Reinitialize slick slider after appending new content
          $('#updatesList').slick('unslick'); // Remove previous slick initialization
          $('#updatesList').slick({
            vertical: true,
            verticalSwiping: true,
            slidesToShow: 3,
            slidesToScroll: 1,
            dots: false,
            infinite: true,
            speed: 500,
            autoplay: true,
            autoplaySpeed: 2000,
            adaptiveHeight: true,
            arrows: false,
          });
        },
        error: function(xhr, status, error) {
          console.error("Error fetching:", error);
        }
      });
    }

    function getTestimonial() {
      const tenant_id = '1';

      $.ajax({
        type: "GET",
        url: `${API_URL}/Manage-Testimonial/List/${tenant_id}`,
        dataType: "json",
        success: function(response) {
          // console.log(response);

          let list = response.data;
          $('#testimonialList').empty(); // Clear existing content

          // Loop through the list and dynamically create the testimonial slides
          $.each(list, function(index, val) {
            let row = `
               <div class="swiper-slide">
                  <div class="testimonial-item">
                    <div class="d-flex">
                      <img src="${val.photo_url}" class="testimonial-img flex-shrink-0"
                        alt="">
                      <div>
                        <h3>${val.name}</h3>
                        <h4>Ceo &amp; Founder</h4>
                        <div class="stars">
                          <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                            class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                        </div>
                      </div>
                    </div>
                    <p>
                      <i class="bi bi-quote quote-icon-left"></i>
                      <span>${val.testimonial_text}</span>
                      <i class="bi bi-quote quote-icon-right"></i>
                    </p>
                  </div>
                </div>

        `;
            $('#testimonialList').append(row);
          });

          // Check if the number of slides is less than required for loop
          const slides = $('#testimonialList .swiper-slide');
          if (slides.length < 3) {
            slides.clone().appendTo('#testimonialList'); // Duplicate slides
          }

          // Reinitialize Swiper after adding the slides
          initializeSwiper();
        },
        error: function(xhr, status, error) {
          console.error("Error fetching testimonials:", error);
        }
      });
    }
    function getCourse() {
      const tenant_id = '1';

      $.ajax({
        type: "GET",
        url: `${API_URL}/Updates/List/${tenant_id}`,
        dataType: "json",
        success: function(response) {
          // console.log(response);

          let list = response.data;
          $('#getCourse').empty(); // Clear existing content

          $.each(list, function(index, val) {
            let row = `
          <div class="single-event">
            <div class="row">
              <div class="col-lg-4 col-sm-12 col-md-12">
                <a href="Updates.php">
                  <img src="${val.display_image}" alt="" class="img-fluid">
                </a>
              </div>
              <div class="event-content col-lg-8 col-sm-12 col-md-12">
                <ul>
                  <li><i class="fa-solid fa-calendar-days"></i>${val.event_date}</li>
                </ul>
                <a href="Update-details.php">
                  <h3>${val.title}</h3>
                </a>
                <div class="d-flex align-items-end justify-content-end">
                  <a href="Updates.php" role="button" class="btn event-btn">
                    View More <i class="fa-solid fa-arrow-right"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        `;
            $('#getCourse').append(row);
          });

        },
        error: function(xhr, status, error) {
          console.error("Error fetching:", error);
        }
      });
    }
  </script>
  <script>
    // Swiper initialization
    var swiper = new Swiper('.mySwiper', {
      slidesPerView: 1,
      loop: true,
      autoplay: {
        delay: 3000, // Adjust the delay as needed
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });
  </script>
  <script>
    var swiper = new Swiper('.swiper', {
      loop: true,
      autoplay: {
        delay: 3000,
        disableOnInteraction: false, // Ensures autoplay doesn't stop permanently after interaction
        pauseOnMouseEnter: true // Pauses autoplay on hover
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      }
    });
  </script>
  <script>
    $(document).ready(function() {
      $(".owl-carousel").owlCarousel({
        items: 4, // Number of items to display
        loop: true, // Loop through items
        margin: 15, // Margin between items
        autoplay: true, // Enable autoplay
        autoplayTimeout: 2000, // Time for each slide (3 seconds)
        autoplayHoverPause: true, // Pause on mouse hover
        responsive: {
          0: {
            items: 1 // Show 1 item for mobile
          },
          600: {
            items: 2 // Show 2 items for small screens
          },
          1000: {
            items: 4 // Show 3 items for larger screens
          }
        }
      });
    });
  </script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      flatpickr("#flatpickr", {
        dateFormat: "Y-m-d", // Customize the date format
        enableTime: false, // Add time picker if needed
        altInput: true, // Show an alternative input
      });
    });
  </script>
  <script>
    var swiper = new Swiper('.swiper-container', {
      loop: true,
      speed: 600,
      autoplay: {
        delay: 5000,
      },
      slidesPerView: 'auto',
      pagination: {
        el: '.swiper-pagination',
        type: 'bullets',
        clickable: true,
      },
      breakpoints: {
        320: {
          slidesPerView: 2,
          spaceBetween: 40,
        },
        480: {
          slidesPerView: 3,
          spaceBetween: 60,
        },
        640: {
          slidesPerView: 4,
          spaceBetween: 80,
        },
        992: {
          slidesPerView: 5,
          spaceBetween: 120,
        },
        1200: {
          slidesPerView: 6,
          spaceBetween: 120,
        },
      },
    });
  </script>

  <script type="text/javascript">
    $(document).ready(function() {
      $('.slider').slick({
        vertical: true, // Enable vertical slider
        verticalSwiping: true, // Enable vertical swiping
        slidesToShow: 3, // Number of slides to show
        slidesToScroll: 1, // Number of slides to scroll
        dots: false, // Disable navigation dots
        infinite: true, // Loop the slides
        speed: 500, // Animation speed
        autoplay: true, // Enable autoplay
        autoplaySpeed: 2000, // Autoplay speed
        adaptiveHeight: true, // Adjust height based on content
        arrows: false // Disable arrows (optional)
      });
    });
  </script>

</body>

</html>