<div class="sidebar">
    <h4>Download</h4>
    <div class="sidebar-content">
        <a href="#"><i class="fa-regular fa-file-pdf"></i> Download Broucher</a>
        <a href="#"><i class="fa-regular fa-file-pdf"></i> Download Broucher</a>
        <a href="#"><i class="fa-regular fa-file-pdf"></i> Download Broucher</a>
    </div>
    <div class="down-btn">
    <a href="" >View More  <i class="fa-solid fa-arrow-right ps-1"></i></a>
    </div>
</div>
