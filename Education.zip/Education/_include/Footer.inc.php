<footer id="footer" class="footer ">

  <div class="container footer-top">
    <div class="row gy-4">
      <div class="col-lg-4 col-md-6 footer-about">
        <a href="index.php" class="logo d-flex align-items-center">
        
          <h3 class="sitename">Education</h3>
        </a>
       <div class="footer-desc">
        <p>Education  is committed to academic excellence, innovation, and shaping future leaders through diverse programs and holistic development.</p>
       </div>
        <div class="social-links d-flex mt-4">
          <a href=""><i class="bi bi-twitter-x"></i></a>
          <a href=""><i class="bi bi-facebook"></i></a>
          <a href=""><i class="bi bi-instagram"></i></a>
          <a href=""><i class="bi bi-linkedin"></i></a>
        </div>
      </div>

      <div class="col-lg-2 col-md-3 footer-links">
        <div class="footer-title"><h3>Useful Links</h3></div>
        <ul>
          <li><a href="#">Home</a></li>
          <li><a href="#"> About us</a></li>
          <li><a href="#"> Services</a></li>
          <li><a href="#"> Terms of service</a></li>
          <li><a href="#">Privacy policy</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-md-3 footer-links">
      <div class="footer-title"><h3>Useful Links</h3></div>
        <ul>
          <li><a href="#">Web Design</a></li>
          <li><a href="#">Web Development</a></li>
          <li><a href="#">Product Management</a></li>
          <li><a href="#">Marketing</a></li>
          <li><a href="#">Graphic Design</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-md-3 footer-address">
      <div class="footer-title"><h3>Our Address</h3></div>
        <ul>
          <li><p><i class="fa-solid fa-location-dot"></i> Address</p></li>
          <li><p><a href="#"><i class="fa-solid fa-phone"></i> +91<span>9999999999</span>, +91<span>9999999999</span> </a></p></li>
          <li><p><a href="#"><i class="fa-solid fa-envelope"></i> <span>admin@gmail.com</span></a></p></li>
          <li><p><a href="#"><i class="fa-solid fa-earth-americas"></i> <span> https://www.poincianahealth.in/SMIT/</span></a></p></li>
       
        </ul>
      </div>
    </div>
  </div>

  <div class="container copyright text-center mt-4">
  <p>© <span>Copyright</span> <strong class="px-1 sitename">Education</strong> <span>All Rights Reserved</span></p>
  <div class="credits">
    <!-- All the links in the footer should remain intact. -->
    <!-- You can delete the links only if you've purchased the pro version. -->
    <!-- Licensing information: https://bootstrapmade.com/license/ -->
    <!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->
    Designed by <a href="#">Atreya Webs</a>
  </div>
</div>

</footer>