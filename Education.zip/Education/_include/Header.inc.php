<div class="header-top">
    <div class="row mx-0">
        <div class="col-lg-9 col-md-12 col-sm-12">
            <div class="container ">
                <div class="row">
                    <div class="col-lg-8 col-md-12 col-sm-12">
                        <div class="news-container" >
                            <div class="news-content" id="scrollingNews">
                                <!-- <span class="news-item">Scrolling News 1</span> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-12 col-md-12 ">
                        <div class="contact-conatiner">
                            <div class="header-contact d-flex"> <i class="fa-solid fa-headphones"></i>
                                <div>
                                    <h5>FOR ADMISSION</h5>
                                    <p class="m-0">
                                        <span>+91 <a href="tel:9348522797">9348522797</a></span>,
                                        <span>+91 <a href="tel:9439337355">9439337355</a></span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-12 col-sm-12">
            <div class="header-text">
                <h5>Follow us:</h5>
            </div>
            <div class="social-links  d-md-flex align-items-center">
                <a href="#" class="twitter"><i class="bi bi-twitter-x"></i></a>
                <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
                <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
                <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
            </div>
        </div>

    </div>
</div>

<div id="header" class="header sticky-top">
    <div class="branding d-flex align-items-center">

        <div class="container  d-flex align-items-center justify-content-between">
            <a href="index.php" class="logo d-flex align-items-center me-auto">
                
                <!-- <img src="assets/img/logo.png" alt=""> -->
                <h1 class="sitename">Education</h1>
            </a>

            <nav id="navmenu" class="navmenu">
                <ul>
                    <li><a href="index.php" class="active">Home<br></a></li>

                    <li class="dropdown"><a href="#"><span>About Us</span> <i
                                class="bi bi-chevron-down toggle-dropdown"></i></a>
                        <ul>
                            <li><a href="About.php">About SMIT</a></li>
                            <li><a href="FAQ.php">FAQ</a></li>
                            <li><a href="testimonial.php">Testimonial</a></li>
                        </ul>
                    </li>
                    <li><a href="information.php">Couses</a></li>

                    <li class="dropdown"><a href="#"><span>Administative</span> <i
                                class="bi bi-chevron-down toggle-dropdown"></i></a>
                        <ul>
                            <li><a href="MeaasageContent.php">Messages</a></li>
                            <li><a href="faculty.php">Faculty</a></li>

                        </ul>
                    </li>
                    <li><a href="information.php">Facilities</a></li>
                    <li><a href="information.php">Academics</a></li>
                    <li class="dropdown"><a href="#"><span>Information Center</span> <i
                                class="bi bi-chevron-down toggle-dropdown"></i></a>
                        <ul>
                            <li><a href="Updates.php">Updates</a></li>
                            <!-- <li class="dropdown"><a href="#"><span>Deep Dropdown</span> <i
                                        class="bi bi-chevron-down toggle-dropdown"></i></a>
                                <ul>
                                    <li><a href="#">Deep Dropdown 1</a></li>
                                    <li><a href="#">Deep Dropdown 2</a></li>
                                    <li><a href="#">Deep Dropdown 3</a></li>
                                    <li><a href="#">Deep Dropdown 4</a></li>
                                    <li><a href="#">Deep Dropdown 5</a></li>
                                </ul>
                            </li> -->
                            <li><a href="Downloads.php">Downloads</a></li>

                        </ul>
                    </li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="Contact.php">Contact</a></li>
                </ul>
                <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
            </nav>



        </div>

    </div>

</div>
<script src="assets/js/APIURL.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" ></script>
<script>
     $(document).ready(function() {
     scrollingNews();

   });

    function scrollingNews() {
        tenant_id = '1';

      $.ajax({
        type: "GET",

        url: `${API_URL}/Scrooling-News/List/${tenant_id}`,
        dataType: "json",
        success: function(response) {
          // console.log(response);
          let list = response.data;
          $('#scrollingNews').empty();

          $.each(list, function(index, val) {
            row = `
                    <span class="news-item"><i class="fa-solid fa-star pe-2"></i>${val.heading}</span>
                    `;
            $('#scrollingNews').append(row);
          });
        },
        error: function(xhr, status, error) {
          console.error("Error fetching :", error);
        }
      });
    }
</script>